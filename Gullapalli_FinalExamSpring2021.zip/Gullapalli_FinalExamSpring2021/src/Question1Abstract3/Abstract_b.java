/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1Abstract3;

/**
 *
 * @author Gullapalli Sai Satyanarayana
 */
public class Abstract_b extends Abstract_a {

    private int x;

    public Abstract_b(int z) {
        this.x = x;
    }

    @Override
    public int sum() {
        return x + x;
    }

    @Override
    public int multiply() {
        return x * x;

    }

}
