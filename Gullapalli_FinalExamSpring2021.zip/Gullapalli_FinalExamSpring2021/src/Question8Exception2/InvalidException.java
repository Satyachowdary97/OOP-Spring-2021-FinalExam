/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question8Exception2;

/**
 *
 * @author Gullapalli Sai Satyanarayana
 */
public class InvalidException extends Exception {

    public InvalidException() {
    }

    public InvalidException(String message) {
        super(message);
    }
}
