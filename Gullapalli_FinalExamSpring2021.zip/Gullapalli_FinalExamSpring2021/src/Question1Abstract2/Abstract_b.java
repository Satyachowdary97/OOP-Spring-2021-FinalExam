/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1Abstract2;

/**
 *
 * @author Gullapalli Sai Satyanarayana
 */
public class Abstract_b extends Abstract_a {

    @Override
    public void getValue(int y) {
        System.out.println("The value of X is :" + y + " in Abstract_b class");
    }

}
