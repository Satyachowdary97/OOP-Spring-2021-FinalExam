/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1Abstract2;

/**
 *
 * @author Gullapalli Sai Satyanarayana
 */
public class Abstract2Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Abstract_b ab = new Abstract_b();
        ab.getValue(8);
        Abstract_a ab1 = new Abstract_b();
        ab1.print();
        ab1.getValue(10);

    }

}
