/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1Abstract1;

/**
 *
 * @author Gullapalli Sai Satyanarayana
 */
public class Abstract_b extends Abstract_a {

    public Abstract_b(int val) {
        super(val);
    }

    @Override
    public void display() {
        System.out.println("Implementing the Display method in Abstract_b class");
    }

}
